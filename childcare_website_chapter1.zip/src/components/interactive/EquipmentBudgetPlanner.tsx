import React, { useState } from 'react';

const EquipmentBudgetPlanner: React.FC = () => {
  const [budget, setBudget] = useState(10000);
  const [ageGroups, setAgeGroups] = useState({
    infants: true,
    toddlers: true,
    preschool: true,
    schoolAge: false
  });
  
  const [cart, setCart] = useState<Array<{
    id: string;
    name: string;
    category: string;
    ageGroup: string;
    price: number;
    essential: boolean;
    quantity: number;
  }>>([]);
  
  const equipmentItems = [
    // Infant Equipment
    { id: 'cribs', name: 'Cribs', category: 'Furniture', ageGroup: 'infants', price: 200, essential: true },
    { id: 'changing_tables', name: 'Changing Tables', category: 'Furniture', ageGroup: 'infants', price: 150, essential: true },
    { id: 'infant_toys', name: 'Sensory Toys', category: 'Toys', ageGroup: 'infants', price: 100, essential: true },
    { id: 'infant_books', name: 'Board Books', category: 'Educational', ageGroup: 'infants', price: 75, essential: true },
    { id: 'infant_mats', name: 'Activity Mats', category: 'Furniture', ageGroup: 'infants', price: 80, essential: false },
    { id: 'infant_swings', name: 'Baby Swings', category: 'Furniture', ageGroup: 'infants', price: 120, essential: false },
    
    // Toddler Equipment
    { id: 'toddler_tables', name: 'Toddler Tables', category: 'Furniture', ageGroup: 'toddlers', price: 120, essential: true },
    { id: 'toddler_chairs', name: 'Toddler Chairs', category: 'Furniture', ageGroup: 'toddlers', price: 40, essential: true },
    { id: 'toddler_toys', name: 'Building Blocks', category: 'Toys', ageGroup: 'toddlers', price: 90, essential: true },
    { id: 'toddler_books', name: 'Picture Books', category: 'Educational', ageGroup: 'toddlers', price: 85, essential: true },
    { id: 'toddler_art', name: 'Art Supplies', category: 'Educational', ageGroup: 'toddlers', price: 70, essential: false },
    { id: 'toddler_music', name: 'Musical Instruments', category: 'Toys', ageGroup: 'toddlers', price: 110, essential: false },
    
    // Preschool Equipment
    { id: 'preschool_tables', name: 'Preschool Tables', category: 'Furniture', ageGroup: 'preschool', price: 150, essential: true },
    { id: 'preschool_chairs', name: 'Preschool Chairs', category: 'Furniture', ageGroup: 'preschool', price: 45, essential: true },
    { id: 'preschool_toys', name: 'Dramatic Play Sets', category: 'Toys', ageGroup: 'preschool', price: 200, essential: true },
    { id: 'preschool_books', name: 'Early Reader Books', category: 'Educational', ageGroup: 'preschool', price: 100, essential: true },
    { id: 'preschool_art', name: 'Art Easels', category: 'Educational', ageGroup: 'preschool', price: 85, essential: false },
    { id: 'preschool_science', name: 'Science Kits', category: 'Educational', ageGroup: 'preschool', price: 120, essential: false },
    
    // School Age Equipment
    { id: 'school_tables', name: 'School-Age Tables', category: 'Furniture', ageGroup: 'schoolAge', price: 180, essential: true },
    { id: 'school_chairs', name: 'School-Age Chairs', category: 'Furniture', ageGroup: 'schoolAge', price: 50, essential: true },
    { id: 'school_games', name: 'Board Games', category: 'Toys', ageGroup: 'schoolAge', price: 150, essential: true },
    { id: 'school_books', name: 'Chapter Books', category: 'Educational', ageGroup: 'schoolAge', price: 120, essential: true },
    { id: 'school_stem', name: 'STEM Materials', category: 'Educational', ageGroup: 'schoolAge', price: 200, essential: false },
    { id: 'school_sports', name: 'Sports Equipment', category: 'Toys', ageGroup: 'schoolAge', price: 180, essential: false },
    
    // General Equipment
    { id: 'storage', name: 'Storage Units', category: 'Furniture', ageGroup: 'general', price: 250, essential: true },
    { id: 'first_aid', name: 'First Aid Kits', category: 'Safety', ageGroup: 'general', price: 60, essential: true },
    { id: 'cleaning', name: 'Cleaning Supplies', category: 'Safety', ageGroup: 'general', price: 100, essential: true },
    { id: 'office', name: 'Office Supplies', category: 'Administrative', ageGroup: 'general', price: 150, essential: true },
    { id: 'tech', name: 'Technology', category: 'Administrative', ageGroup: 'general', price: 500, essential: false },
    { id: 'outdoor', name: 'Outdoor Play Equipment', category: 'Toys', ageGroup: 'general', price: 400, essential: false }
  ];
  
  const addToCart = (item) => {
    const existingItem = cart.find(cartItem => cartItem.id === item.id);
    
    if (existingItem) {
      setCart(cart.map(cartItem => 
        cartItem.id === item.id 
          ? { ...cartItem, quantity: cartItem.quantity + 1 } 
          : cartItem
      ));
    } else {
      setCart([...cart, { ...item, quantity: 1 }]);
    }
  };
  
  const removeFromCart = (itemId) => {
    setCart(cart.filter(item => item.id !== itemId));
  };
  
  const updateQuantity = (itemId, quantity) => {
    if (quantity < 1) return;
    
    setCart(cart.map(item => 
      item.id === itemId 
        ? { ...item, quantity } 
        : item
    ));
  };
  
  const getTotalCost = () => {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  };
  
  const getFilteredItems = () => {
    return equipmentItems.filter(item => {
      if (item.ageGroup === 'general') return true;
      return ageGroups[item.ageGroup];
    });
  };
  
  const getEssentialItems = () => {
    return getFilteredItems().filter(item => item.essential);
  };
  
  const getOptionalItems = () => {
    return getFilteredItems().filter(item => !item.essential);
  };
  
  const getEssentialCost = () => {
    const essentialItems = cart.filter(item => {
      const originalItem = equipmentItems.find(equip => equip.id === item.id);
      return originalItem && originalItem.essential;
    });
    
    return essentialItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  };
  
  const getOptionalCost = () => {
    const optionalItems = cart.filter(item => {
      const originalItem = equipmentItems.find(equip => equip.id === item.id);
      return originalItem && !originalItem.essential;
    });
    
    return optionalItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  };
  
  const getRemainingBudget = () => {
    return budget - getTotalCost();
  };
  
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  };
  
  return (
    <div className="interactive-element p-4 border border-input rounded-lg">
      <h3 className="text-xl font-bold mb-4 flex items-center">
        <span className="mr-2">💰</span> Equipment Budget Planner
      </h3>
      
      <div className="mb-6">
        <label className="block text-sm font-medium mb-1">Total Budget</label>
        <div className="flex items-center">
          <input
            type="range"
            min="5000"
            max="50000"
            step="1000"
            value={budget}
            onChange={(e) => setBudget(parseInt(e.target.value))}
            className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer mr-4"
          />
          <span className="font-bold text-lg">{formatCurrency(budget)}</span>
        </div>
      </div>
      
      <div className="mb-6">
        <h4 className="font-bold mb-2">Age Groups</h4>
        <div className="flex flex-wrap gap-2">
          <label className="flex items-center p-2 border rounded-md cursor-pointer">
            <input
              type="checkbox"
              checked={ageGroups.infants}
              onChange={() => setAgeGroups({...ageGroups, infants: !ageGroups.infants})}
              className="mr-2"
            />
            <span>Infants (0-1)</span>
          </label>
          <label className="flex items-center p-2 border rounded-md cursor-pointer">
            <input
              type="checkbox"
              checked={ageGroups.toddlers}
              onChange={() => setAgeGroups({...ageGroups, toddlers: !ageGroups.toddlers})}
              className="mr-2"
            />
            <span>Toddlers (1-3)</span>
          </label>
          <label className="flex items-center p-2 border rounded-md cursor-pointer">
            <input
              type="checkbox"
              checked={ageGroups.preschool}
              onChange={() => setAgeGroups({...ageGroups, preschool: !ageGroups.preschool})}
              className="mr-2"
            />
            <span>Preschool (3-5)</span>
          </label>
          <label className="flex items-center p-2 border rounded-md cursor-pointer">
            <input
              type="checkbox"
              checked={ageGroups.schoolAge}
              onChange={() => setAgeGroups({...ageGroups, schoolAge: !ageGroups.schoolAge})}
              className="mr-2"
            />
            <span>School Age (5+)</span>
          </label>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <h4 className="font-bold mb-3 flex items-center">
            <span className="mr-2">⭐</span> Essential Equipment
          </h4>
          <div className="bg-card rounded-lg p-4 h-64 overflow-y-auto">
            {getEssentialItems().map(item => (
              <div key={item.id} className="flex justify-between items-center p-2 border-b">
                <div>
                  <div className="font-medium">{item.name}</div>
                  <div className="text-xs text-muted-foreground">{item.category} • {item.ageGroup === 'general' ? 'All Ages' : item.ageGroup}</div>
                </div>
                <div className="flex items-center">
                  <div className="mr-3 font-medium">{formatCurrency(item.price)}</div>
                  <button
                    onClick={() => addToCart(item)}
                    className="p-1 bg-secondary text-secondary-foreground rounded-md hover:bg-secondary/80 transition-colors"
                  >
                    +
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div>
          <h4 className="font-bold mb-3 flex items-center">
            <span className="mr-2">✨</span> Optional Equipment
          </h4>
          <div className="bg-card rounded-lg p-4 h-64 overflow-y-auto">
            {getOptionalItems().map(item => (
              <div key={item.id} className="flex justify-between items-center p-2 border-b">
                <div>
                  <div className="font-medium">{item.name}</div>
                  <div className="text-xs text-muted-foreground">{item.category} • {item.ageGroup === 'general' ? 'All Ages' : item.ageGroup}</div>
                </div>
                <div className="flex items-center">
                  <div className="mr-3 font-medium">{formatCurrency(item.price)}</div>
                  <button
                    onClick={() => addToCart(item)}
                    className="p-1 bg-secondary text-secondary-foreground rounded-md hover:bg-secondary/80 transition-colors"
                  >
                    +
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      <div className="mb-6">
        <h4 className="font-bold mb-3 flex items-center">
          <span className="mr-2">🛒</span> Shopping Cart
        </h4>
        <div className="bg-card rounded-lg p-4">
          {cart.length === 0 ? (
            <p className="text-center text-muted-foreground py-4">Your cart is empty</p>
          ) : (
            <>
              <div className="max-h-64 overflow-y-auto mb-4">
                {cart.map(item => (
                  <div key={item.id} className="flex justify-between items-center p-2 border-b">
                    <div className="flex-1">
                      <div className="font-medium">{item.name}</div>
                      <div className="text-xs text-muted-foreground">{item.category} • {item.ageGroup === 'general' ? 'All Ages' : item.ageGroup}</div>
                    </div>
                    <div className="flex items-center">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="p-1 bg-muted text-muted-foreground rounded-md hover:bg-muted/80 transition-colors"
                      >
                        -
                      </button>
                      <span className="mx-2 w-8 text-center">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="p-1 bg-muted text-muted-foreground rounded-md hover:bg-muted/80 transition-colors"
                      >
                        +
                      </button>
                      <div className="mx-3 font-medium">{formatCurrency(item.price * item.quantity)}</div>
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="p-1 bg-destructive text-destructive-foreground rounded-md hover:bg-destructive/80 transition-colors"
                      >
                        ×
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="border-t pt-4">
                <div className="flex justify-between mb-1">
                  <span>Essential Items:</span>
                  <span>{formatCurrency(getEssentialCost())}</span>
                </div>
                <div className="flex justify-between mb-1">
                  <span>Optional Items:</span>
                  <span>{formatCurrency(getOptionalCost())}</span>
                </div>
                <div className="flex justify-between font-bold">
                  <span>Total:</span>
                  <span>{formatCurrency(getTotalCost())}</span>
                </div>
                <div className="flex justify-between mt-2 text-sm">
                  <span>Remaining Budget:</span>
                  <span className={getRemainingBudget() < 0 ? 'text-destructive' : 'text-secondary'}>
                    {formatCurrency(getRemainingBudget())}
                  </span>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
      
      <div className="flex justify-between">
        <button
          onClick={() => setCart([])}
          className="px-4 py-2 bg-muted text-muted-foreground rounded-md hover:bg-muted/80 transition-colors"
        >
          Clear Cart
        </button>
        <button
          onClick={() => alert('Budget plan saved!')}
          className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/80 transition-colors"
        >
          Save Budget Plan
        </button>
      </div>
    </div>
  );
};

export default EquipmentBudgetPlanner;
