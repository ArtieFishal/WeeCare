import React, { useState } from 'react';

const RoomLayoutDesigner: React.FC = () => {
  const [roomSize, setRoomSize] = useState({ width: 30, length: 40 });
  const [selectedItem, setSelectedItem] = useState<string | null>(null);
  const [placedItems, setPlacedItems] = useState<Array<{id: string, type: string, x: number, y: number, rotation: number}>>([]);
  const [viewMode, setViewMode] = useState<'2d' | '3d'>('2d');
  const [safetyIssues, setSafetyIssues] = useState<Array<{id: string, description: string, severity: 'high' | 'medium' | 'low'}>>([]);
  
  const furnitureItems = [
    { id: 'table', label: 'Table', icon: '🪑', category: 'furniture' },
    { id: 'chair', label: 'Chair', icon: '🪑', category: 'furniture' },
    { id: 'bookshelf', label: 'Bookshelf', icon: '📚', category: 'furniture' },
    { id: 'toy_bin', label: 'Toy Bin', icon: '🧸', category: 'storage' },
    { id: 'art_easel', label: 'Art Easel', icon: '🎨', category: 'activity' },
    { id: 'play_kitchen', label: 'Play Kitchen', icon: '🍳', category: 'activity' },
    { id: 'reading_nook', label: 'Reading Nook', icon: '📖', category: 'quiet' },
    { id: 'nap_area', label: 'Nap Area', icon: '😴', category: 'quiet' },
    { id: 'door', label: 'Door', icon: '🚪', category: 'safety' },
    { id: 'window', label: 'Window', icon: '🪟', category: 'safety' },
    { id: 'fire_extinguisher', label: 'Fire Extinguisher', icon: '🧯', category: 'safety' }
  ];
  
  const handleAddItem = () => {
    if (!selectedItem) return;
    
    const newItem = {
      id: `${selectedItem}_${Date.now()}`,
      type: selectedItem,
      x: Math.floor(Math.random() * (roomSize.width - 5)) + 2,
      y: Math.floor(Math.random() * (roomSize.length - 5)) + 2,
      rotation: 0
    };
    
    setPlacedItems([...placedItems, newItem]);
    checkSafetyIssues([...placedItems, newItem]);
  };
  
  const handleRemoveItem = (id: string) => {
    const updatedItems = placedItems.filter(item => item.id !== id);
    setPlacedItems(updatedItems);
    checkSafetyIssues(updatedItems);
  };
  
  const handleMoveItem = (id: string, newX: number, newY: number) => {
    const updatedItems = placedItems.map(item => 
      item.id === id ? { ...item, x: newX, y: newY } : item
    );
    setPlacedItems(updatedItems);
    checkSafetyIssues(updatedItems);
  };
  
  const handleRotateItem = (id: string) => {
    const updatedItems = placedItems.map(item => 
      item.id === id ? { ...item, rotation: (item.rotation + 90) % 360 } : item
    );
    setPlacedItems(updatedItems);
  };
  
  const checkSafetyIssues = (items: typeof placedItems) => {
    const issues: Array<{id: string, description: string, severity: 'high' | 'medium' | 'low'}> = [];
    
    // Check for blocked exits
    const doors = items.filter(item => item.type === 'door');
    if (doors.length === 0) {
      issues.push({
        id: 'no_door',
        description: 'Room has no exit door',
        severity: 'high'
      });
    }
    
    // Check for fire safety
    const fireExtinguishers = items.filter(item => item.type === 'fire_extinguisher');
    if (fireExtinguishers.length === 0) {
      issues.push({
        id: 'no_fire_extinguisher',
        description: 'Room has no fire extinguisher',
        severity: 'high'
      });
    }
    
    // Check for overcrowding
    const totalItems = items.length;
    const roomArea = roomSize.width * roomSize.length;
    if (totalItems > roomArea / 20) {
      issues.push({
        id: 'overcrowded',
        description: 'Room may be overcrowded with furniture',
        severity: 'medium'
      });
    }
    
    // Check for balanced activity areas
    const activityItems = items.filter(item => 
      furnitureItems.find(f => f.id === item.type)?.category === 'activity'
    ).length;
    
    const quietItems = items.filter(item => 
      furnitureItems.find(f => f.id === item.type)?.category === 'quiet'
    ).length;
    
    if (activityItems === 0) {
      issues.push({
        id: 'no_activity_area',
        description: 'Room has no activity areas',
        severity: 'medium'
      });
    }
    
    if (quietItems === 0) {
      issues.push({
        id: 'no_quiet_area',
        description: 'Room has no quiet areas',
        severity: 'medium'
      });
    }
    
    setSafetyIssues(issues);
  };
  
  return (
    <div className="interactive-element p-4 border border-input rounded-lg">
      <h3 className="text-xl font-bold mb-4 flex items-center">
        <span className="mr-2">🏗️</span> Room Layout Designer
      </h3>
      
      <div className="mb-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Room Width (feet)</label>
          <input
            type="range"
            min="10"
            max="50"
            value={roomSize.width}
            onChange={(e) => setRoomSize({...roomSize, width: parseInt(e.target.value)})}
            className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer"
          />
          <div className="flex justify-between text-xs mt-1">
            <span>10 ft</span>
            <span>{roomSize.width} ft</span>
            <span>50 ft</span>
          </div>
        </div>
        
        <div>
          <label className="block text-sm font-medium mb-1">Room Length (feet)</label>
          <input
            type="range"
            min="10"
            max="50"
            value={roomSize.length}
            onChange={(e) => setRoomSize({...roomSize, length: parseInt(e.target.value)})}
            className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer"
          />
          <div className="flex justify-between text-xs mt-1">
            <span>10 ft</span>
            <span>{roomSize.length} ft</span>
            <span>50 ft</span>
          </div>
        </div>
      </div>
      
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <h4 className="font-bold">Furniture & Equipment</h4>
          <div className="flex items-center">
            <button
              onClick={() => setViewMode(viewMode === '2d' ? '3d' : '2d')}
              className="px-3 py-1 bg-accent text-accent-foreground rounded-md text-sm hover:bg-accent/80 transition-colors"
            >
              {viewMode === '2d' ? '3D View' : '2D View'}
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-6 gap-2 mb-4">
          {furnitureItems.map(item => (
            <button
              key={item.id}
              onClick={() => setSelectedItem(item.id)}
              className={`p-2 rounded-md flex flex-col items-center justify-center text-center h-20 transition-colors ${
                selectedItem === item.id 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-card hover:bg-muted'
              }`}
            >
              <span className="text-2xl mb-1">{item.icon}</span>
              <span className="text-xs">{item.label}</span>
            </button>
          ))}
        </div>
        
        <div className="flex space-x-2 mb-4">
          <button
            onClick={handleAddItem}
            disabled={!selectedItem}
            className="px-4 py-2 bg-secondary text-secondary-foreground rounded-md hover:bg-secondary/80 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            Add Selected Item
          </button>
          <button
            onClick={() => setPlacedItems([])}
            disabled={placedItems.length === 0}
            className="px-4 py-2 bg-destructive text-destructive-foreground rounded-md hover:bg-destructive/80 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            Clear All
          </button>
        </div>
      </div>
      
      <div className="mb-6">
        <div className="relative border border-input rounded-lg overflow-hidden" 
             style={{
               width: '100%',
               height: '400px',
               backgroundColor: viewMode === '3d' ? '#f5f5f5' : '#ffffff',
               perspective: viewMode === '3d' ? '1000px' : 'none'
             }}>
          {/* Room grid */}
          <div className={`absolute inset-0 ${viewMode === '3d' ? 'transform-gpu rotate-x-60 scale-75' : ''}`}
               style={{
                 display: 'grid',
                 gridTemplateColumns: `repeat(${roomSize.width}, 10px)`,
                 gridTemplateRows: `repeat(${roomSize.length}, 10px)`,
                 transformStyle: 'preserve-3d'
               }}>
            {/* Grid lines would be rendered here */}
          </div>
          
          {/* Placed items */}
          {placedItems.map(item => {
            const furnitureItem = furnitureItems.find(f => f.id === item.type);
            return (
              <div
                key={item.id}
                className={`absolute flex items-center justify-center cursor-move ${
                  viewMode === '3d' ? 'shadow-lg' : ''
                }`}
                style={{
                  left: `${(item.x / roomSize.width) * 100}%`,
                  top: `${(item.y / roomSize.length) * 100}%`,
                  width: '40px',
                  height: '40px',
                  transform: `rotate(${item.rotation}deg) ${viewMode === '3d' ? 'translateZ(20px)' : ''}`,
                  backgroundColor: viewMode === '3d' ? '#ffffff' : 'transparent',
                  borderRadius: viewMode === '3d' ? '4px' : '0',
                  zIndex: viewMode === '3d' ? 10 : 1
                }}
                onClick={() => handleRemoveItem(item.id)}
              >
                <span className="text-2xl">{furnitureItem?.icon}</span>
              </div>
            );
          })}
        </div>
      </div>
      
      {safetyIssues.length > 0 && (
        <div className="mb-6 p-4 bg-card rounded-lg border-l-4 border-warning">
          <h4 className="font-bold flex items-center mb-2">
            <span className="mr-2">⚠️</span> Safety Considerations
          </h4>
          <ul className="space-y-2">
            {safetyIssues.map(issue => (
              <li key={issue.id} className="flex items-start">
                <span className={`inline-block w-2 h-2 mt-1.5 mr-2 rounded-full ${
                  issue.severity === 'high' ? 'bg-destructive' : 
                  issue.severity === 'medium' ? 'bg-warning' : 'bg-muted'
                }`}></span>
                <span>{issue.description}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      
      <div className="flex justify-between">
        <button
          className="px-4 py-2 bg-accent text-accent-foreground rounded-md hover:bg-accent/80 transition-colors"
          onClick={() => alert('Layout saved!')}
        >
          Save Layout
        </button>
        <button
          className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/80 transition-colors"
          onClick={() => alert('Layout exported!')}
        >
          Export as PDF
        </button>
      </div>
    </div>
  );
};

export default RoomLayoutDesigner;
