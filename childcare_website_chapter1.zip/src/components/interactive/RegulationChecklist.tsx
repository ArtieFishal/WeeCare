import React, { useState, useEffect } from 'react';
import { Card, CardContent } from "../ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Textarea } from "../ui/textarea";
import { Input } from "../ui/input";
import { Alert, AlertDescription } from "../ui/alert";

interface RegulationItem {
  id: string;
  category: string;
  description: string;
  reference: string;
  url?: string;
  priority: 'critical' | 'high' | 'medium' | 'low';
}

interface ChecklistState {
  checked: Record<string, boolean>;
  notes: Record<string, string>;
  centerInfo: {
    name: string;
    address: string;
    license: string;
    director: string;
    phone: string;
    email: string;
  };
  lastSaved: string;
}

const RegulationChecklist: React.FC = () => {
  const initialState: ChecklistState = {
    checked: {},
    notes: {},
    centerInfo: {
      name: '',
      address: '',
      license: '',
      director: '',
      phone: '',
      email: ''
    },
    lastSaved: ''
  };

  const [state, setState] = useState<ChecklistState>(initialState);
  const [activeTab, setActiveTab] = useState('checklist');
  const [showSavedAlert, setShowSavedAlert] = useState(false);
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterPriority, setFilterPriority] = useState<string>('all');
  
  const regulations: RegulationItem[] = [
    { 
      id: 'staff_qual', 
      category: 'Staff Qualifications', 
      description: 'All staff members are at least 18 years old with high school diploma or equivalent', 
      reference: 'TN Rule 1240-04-01-.07(3)(a)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'critical'
    },
    { 
      id: 'background', 
      category: 'Staff Qualifications', 
      description: 'All staff have completed comprehensive background checks through TN DHS', 
      reference: 'TN Rule 1240-04-01-.07(1)(a)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'critical'
    },
    { 
      id: 'immunization', 
      category: 'Staff Qualifications', 
      description: 'All staff have provided proof of immunization per TN Department of Health requirements', 
      reference: 'TN Rule 1240-04-01-.07(6)(b)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'high'
    },
    { 
      id: 'cpr_first_aid', 
      category: 'Staff Qualifications', 
      description: 'At least one staff member with current CPR and First Aid certification is present at all times', 
      reference: 'TN Rule 1240-04-01-.12(10)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'critical'
    },
    { 
      id: 'director_quals', 
      category: 'Staff Qualifications', 
      description: 'Director meets all qualification requirements including education and experience', 
      reference: 'TN Rule 1240-04-01-.07(4)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'high'
    },
    { 
      id: 'ratio_infant', 
      category: 'Staff-to-Child Ratios', 
      description: 'One staff member for every four infants (6 weeks-15 months)', 
      reference: 'TN Rule 1240-04-01-.11(Table A)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'critical'
    },
    { 
      id: 'ratio_toddler', 
      category: 'Staff-to-Child Ratios', 
      description: 'One staff member for every six toddlers (12-30 months)', 
      reference: 'TN Rule 1240-04-01-.11(Table A)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'critical'
    },
    { 
      id: 'ratio_preschool', 
      category: 'Staff-to-Child Ratios', 
      description: 'One staff member for every seven preschoolers (2.5-3 years)', 
      reference: 'TN Rule 1240-04-01-.11(Table A)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'critical'
    },
    { 
      id: 'ratio_prek', 
      category: 'Staff-to-Child Ratios', 
      description: 'One staff member for every thirteen pre-K children (4-5 years)', 
      reference: 'TN Rule 1240-04-01-.11(Table A)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'critical'
    },
    { 
      id: 'group_size', 
      category: 'Staff-to-Child Ratios', 
      description: 'Maximum group sizes are maintained according to age groups', 
      reference: 'TN Rule 1240-04-01-.11(Table A)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'high'
    },
    { 
      id: 'lighting', 
      category: 'Facility Requirements', 
      description: 'Adequate lighting of at least fifty (50) foot-candles of light', 
      reference: 'TN Rule 1240-04-01-.14(2)(a)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'medium'
    },
    { 
      id: 'ventilation', 
      category: 'Facility Requirements', 
      description: 'Proper ventilation and temperature maintained between 68-78 degrees F', 
      reference: 'TN Rule 1240-04-01-.14(2)(b)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'medium'
    },
    { 
      id: 'square_footage', 
      category: 'Facility Requirements', 
      description: 'Indoor space of at least thirty (30) square feet per child', 
      reference: 'TN Rule 1240-04-01-.14(3)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'high'
    },
    { 
      id: 'outdoor_space', 
      category: 'Facility Requirements', 
      description: 'Outdoor play area of at least fifty (50) square feet per child', 
      reference: 'TN Rule 1240-04-01-.14(4)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'high'
    },
    { 
      id: 'sanitation', 
      category: 'Facility Requirements', 
      description: 'Appropriate sanitation facilities and procedures following TN Department of Health guidelines', 
      reference: 'TN Rule 1240-04-01-.14(10)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'high'
    },
    { 
      id: 'secure_entrance', 
      category: 'Facility Requirements', 
      description: 'Secure entrance and exit with controlled access system', 
      reference: 'TN Rule 1240-04-01-.14(7)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'critical'
    },
    { 
      id: 'monitoring', 
      category: 'Facility Requirements', 
      description: 'System for monitoring children\'s whereabouts at all times', 
      reference: 'TN Rule 1240-04-01-.11(7)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'critical'
    },
    { 
      id: 'curriculum', 
      category: 'Curriculum Requirements', 
      description: 'Developmentally appropriate curriculum aligned with TN Early Learning Development Standards', 
      reference: 'TN Rule 1240-04-01-.15',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'high'
    },
    { 
      id: 'activities', 
      category: 'Curriculum Requirements', 
      description: 'Range of activities including arts, music, and minimum 60 minutes of outdoor play daily (weather permitting)', 
      reference: 'TN Rule 1240-04-01-.15(3)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'medium'
    },
    { 
      id: 'screen_time', 
      category: 'Curriculum Requirements', 
      description: 'Screen time limited to 30 minutes per day for children over 2 years', 
      reference: 'TN Rule 1240-04-01-.15(7)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'medium'
    },
    { 
      id: 'emergency_plan', 
      category: 'Health and Safety', 
      description: 'Written emergency preparedness plan meeting TN requirements', 
      reference: 'TN Rule 1240-04-01-.18',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'critical'
    },
    { 
      id: 'incident_reporting', 
      category: 'Health and Safety', 
      description: 'System for reporting incidents to TN DHS within 24 hours', 
      reference: 'TN Rule 1240-04-01-.09',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'high'
    },
    { 
      id: 'medication', 
      category: 'Health and Safety', 
      description: 'Proper medication administration and storage procedures', 
      reference: 'TN Rule 1240-04-01-.12(10)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'critical'
    },
    { 
      id: 'transportation', 
      category: 'Transportation', 
      description: 'Transportation requirements including proper vehicle inspection and driver qualifications', 
      reference: 'TN Rule 1240-04-01-.17',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'critical'
    },
    { 
      id: 'food_service', 
      category: 'Health and Safety', 
      description: 'Food service meeting USDA and TN nutritional guidelines', 
      reference: 'TN Rule 1240-04-01-.13',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'high'
    },
    { 
      id: 'child_records', 
      category: 'Record Keeping', 
      description: 'Complete and up-to-date records for each child including immunizations', 
      reference: 'TN Rule 1240-04-01-.08',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'high'
    },
    { 
      id: 'staff_records', 
      category: 'Record Keeping', 
      description: 'Complete personnel records for all staff including qualifications and training', 
      reference: 'TN Rule 1240-04-01-.08',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'high'
    },
    { 
      id: 'posted_items', 
      category: 'Record Keeping', 
      description: 'Required items posted including license, emergency numbers, and menus', 
      reference: 'TN Rule 1240-04-01-.08(7)',
      url: 'https://publications.tnsosfiles.com/rules/1240/1240-04/1240-04-01.20220629.pdf',
      priority: 'medium'
    }
  ];
  
  const categories = [...new Set(regulations.map(item => item.category))];
  
  // Load saved state from localStorage on component mount
  useEffect(() => {
    const savedState = localStorage.getItem('tnRegulationChecklist');
    if (savedState) {
      setState(JSON.parse(savedState));
    }
  }, []);

  const handleCheck = (id: string) => {
    setState(prev => {
      const newState = {
        ...prev,
        checked: {
          ...prev.checked,
          [id]: !prev.checked[id]
        }
      };
      
      // Save to localStorage
      localStorage.setItem('tnRegulationChecklist', JSON.stringify(newState));
      
      return newState;
    });
  };
  
  const handleNoteChange = (id: string, note: string) => {
    setState(prev => {
      const newState = {
        ...prev,
        notes: {
          ...prev.notes,
          [id]: note
        }
      };
      
      return newState;
    });
  };
  
  const handleCenterInfoChange = (field: keyof ChecklistState['centerInfo'], value: string) => {
    setState(prev => ({
      ...prev,
      centerInfo: {
        ...prev.centerInfo,
        [field]: value
      }
    }));
  };
  
  const saveData = () => {
    const newState = {
      ...state,
      lastSaved: new Date().toLocaleString()
    };
    
    localStorage.setItem('tnRegulationChecklist', JSON.stringify(newState));
    setState(newState);
    setShowSavedAlert(true);
    
    setTimeout(() => {
      setShowSavedAlert(false);
    }, 3000);
  };
  
  const exportData = () => {
    const dataStr = JSON.stringify(state, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `tn_childcare_regulations_${new Date().toISOString().slice(0, 10)}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };
  
  const importData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    if (event.target.files && event.target.files.length > 0) {
      fileReader.readAsText(event.target.files[0], "UTF-8");
      fileReader.onload = e => {
        if (e.target?.result) {
          try {
            const parsedData = JSON.parse(e.target.result as string) as ChecklistState;
            setState(parsedData);
            localStorage.setItem('tnRegulationChecklist', JSON.stringify(parsedData));
            setShowSavedAlert(true);
            setTimeout(() => {
              setShowSavedAlert(false);
            }, 3000);
          } catch (error) {
            console.error("Error parsing imported data:", error);
            alert("Invalid file format. Please upload a valid JSON file.");
          }
        }
      };
    }
  };
  
  const resetData = () => {
    if (window.confirm("Are you sure you want to reset all data? This cannot be undone.")) {
      localStorage.removeItem('tnRegulationChecklist');
      setState(initialState);
    }
  };
  
  const calculateProgress = () => {
    const totalItems = regulations.length;
    const checkedCount = Object.values(state.checked).filter(Boolean).length;
    return Math.round((checkedCount / totalItems) * 100);
  };
  
  const calculateCategoryProgress = (category: string) => {
    const categoryItems = regulations.filter(reg => reg.category === category);
    const checkedCategoryItems = categoryItems.filter(reg => state.checked[reg.id]);
    return Math.round((checkedCategoryItems.length / categoryItems.length) * 100);
  };
  
  const getPriorityColor = (priority: string) => {
    switch(priority) {
      case 'critical': return 'text-destructive';
      case 'high': return 'text-warning';
      case 'medium': return 'text-secondary';
      case 'low': return 'text-muted-foreground';
      default: return '';
    }
  };
  
  const getFilteredRegulations = () => {
    return regulations.filter(reg => {
      const categoryMatch = filterCategory === 'all' || reg.category === filterCategory;
      const statusMatch = filterStatus === 'all' || 
                         (filterStatus === 'completed' && state.checked[reg.id]) || 
                         (filterStatus === 'pending' && !state.checked[reg.id]);
      const priorityMatch = filterPriority === 'all' || reg.priority === filterPriority;
      
      return categoryMatch && statusMatch && priorityMatch;
    });
  };
  
  const generateCompliancePlan = () => {
    const pendingItems = regulations.filter(reg => !state.checked[reg.id])
                                   .sort((a, b) => {
                                     const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
                                     return priorityOrder[a.priority] - priorityOrder[b.priority];
                                   });
    
    if (pendingItems.length === 0) {
      return "Congratulations! You have completed all regulatory requirements.";
    }
    
    return (
      <div className="space-y-4">
        <h4 className="font-bold">Compliance Action Plan</h4>
        <p className="text-sm text-muted-foreground mb-4">
          Based on your checklist, here are the pending items in order of priority:
        </p>
        
        {pendingItems.map((item, index) => (
          <div key={item.id} className="border-l-4 pl-4 py-2 mb-4" style={{
            borderColor: 
              item.priority === 'critical' ? 'var(--destructive)' : 
              item.priority === 'high' ? 'var(--warning)' : 
              item.priority === 'medium' ? 'var(--secondary)' : 'var(--muted)'
          }}>
            <div className="flex justify-between">
              <h5 className="font-medium">
                {index + 1}. {item.description}
              </h5>
              <Badge variant={
                item.priority === 'critical' ? 'destructive' : 
                item.priority === 'high' ? 'outline' : 
                item.priority === 'medium' ? 'secondary' : 'default'
              }>
                {item.priority}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-1">{item.reference}</p>
            <div className="mt-2">
              <p className="text-sm">
                <strong>Suggested Action:</strong> {
                  item.priority === 'critical' ? 'Address immediately to avoid potential license issues.' :
                  item.priority === 'high' ? 'Complete within 1-2 weeks.' :
                  item.priority === 'medium' ? 'Schedule for completion within 30 days.' :
                  'Add to your long-term improvement plan.'
                }
              </p>
              {item.url && (
                <a 
                  href={item.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-xs text-primary hover:underline mt-1 inline-block"
                >
                  View official regulation
                </a>
              )}
            </div>
          </div>
        ))}
      </div>
    );
  };
  
  const handlePrint = () => {
    window.print();
  };
  
  return (
    <div className="interactive-element border border-input rounded-lg">
      <div className="p-4 bg-card">
        <h3 className="text-xl font-bold mb-4 flex items-center">
          <span className="mr-2">📋</span> Tennessee Child Care Regulation Compliance Tool
        </h3>
        
        {showSavedAlert && (
          <Alert className="mb-4">
            <AlertDescription>
              Data saved successfully! Last saved: {state.lastSaved}
            </AlertDescription>
          </Alert>
        )}
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="checklist">Checklist</TabsTrigger>
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="center-info">Center Info</TabsTrigger>
            <TabsTrigger value="action-plan">Action Plan</TabsTrigger>
          </TabsList>
          
          <TabsContent value="checklist" className="mt-4">
            <div className="mb-6">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Overall Compliance</span>
                <span className="text-sm font-medium">{calculateProgress()}%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2.5">
                <div 
                  className="bg-primary h-2.5 rounded-full transition-all duration-500" 
                  style={{ width: `${calculateProgress()}%` }}
                ></div>
              </div>
            </div>
            
            <div className="flex flex-wrap gap-2 mb-4">
              <div>
                <label className="text-sm font-medium block mb-1">Category</label>
                <select 
                  value={filterCategory}
                  onChange={(e) => setFilterCategory(e.target.value)}
                  className="p-2 text-sm rounded-md border border-input bg-background"
                >
                  <option value="all">All Categories</option>
                  {categories.map(category => (
                    <option key={category} value={category}>{category}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="text-sm font-medium block mb-1">Status</label>
                <select 
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="p-2 text-sm rounded-md border border-input bg-background"
                >
                  <option value="all">All Items</option>
                  <option value="completed">Completed</option>
                  <option value="pending">Pending</option>
                </select>
              </div>
              
              <div>
                <label className="text-sm font-medium block mb-1">Priority</label>
                <select 
                  value={filterPriority}
                  onChange={(e) => setFilterPriority(e.target.value)}
                  className="p-2 text-sm rounded-md border border-input bg-background"
                >
                  <option value="all">All Priorities</option>
                  <option value="critical">Critical</option>
                  <option value="high">High</option>
                  <option value="medium">Medium</option>
                  <option value="low">Low</option>
                </select>
              </div>
            </div>
            
            <div className="space-y-6">
              {getFilteredRegulations().length > 0 ? (
                getFilteredRegulations().map(regulation => (
                  <Card key={regulation.id} className={`transition-colors ${
                    state.checked[regulation.id] ? 'bg-primary/5 border-primary/20' : 'bg-card'
                  }`}>
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <input
                          type="checkbox"
                          id={regulation.id}
                          checked={!!state.checked[regulation.id]}
                          onChange={() => handleCheck(regulation.id)}
                          className="h-5 w-5 rounded border-gray-300 text-primary focus:ring-primary mt-1"
                        />
                        <div className="flex-1">
                          <div className="flex flex-wrap justify-between gap-2">
                            <label htmlFor={regulation.id} className="font-medium cursor-pointer">
                              {regulation.description}
                            </label>
                            <Badge variant={
                              regulation.priority === 'critical' ? 'destructive' : 
                              regulation.priority === 'high' ? 'outline' : 
                              regulation.priority === 'medium' ? 'secondary' : 'default'
                            }>
                              {regulation.priority}
                            </Badge>
                          </div>
                          
                          <div className="flex flex-wrap items-center gap-2 mt-1 text-xs text-muted-foreground">
                            <span>{regulation.category}</span>
                            <span>•</span>
                            <span>{regulation.reference}</span>
                            {regulation.url && (
                              <>
                                <span>•</span>
                                <a 
                                  href={regulation.url} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="text-primary hover:underline"
                                >
                                  View regulation
                                </a>
                              </>
                            )}
                          </div>
                          
                          <div className="mt-3">
                            <Textarea
                              placeholder="Add notes about compliance status, action items, or documentation..."
                              value={state.notes[regulation.id] || ''}
                              onChange={(e) => handleNoteChange(regulation.id, e.target.value)}
                              className="min-h-[60px] text-sm"
                            />
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  No items match your current filters.
                </div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="dashboard" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <Card>
                <CardContent className="p-4">
                  <h4 className="font-bold mb-2">Overall Compliance</h4>
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-full border-4 flex items-center justify-center font-bold text-xl" style={{
                      borderColor: 
                        calculateProgress() >= 90 ? 'var(--success, var(--secondary))' : 
                        calculateProgress() >= 70 ? 'var(--warning, var(--highlight))' : 
                        'var(--destructive)'
                    }}>
                      {calculateProgress()}%
                    </div>
                    <div>
                      <p className="text-sm">
                        {calculateProgress() >= 90 ? 'Excellent compliance level!' : 
                         calculateProgress() >= 70 ? 'Good progress, keep going!' : 
                         'Needs immediate attention'}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {Object.values(state.checked).filter(Boolean).length} of {regulations.length} requirements met
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <h4 className="font-bold mb-2">Priority Status</h4>
                  <div className="space-y-2">
                    {['critical', 'high', 'medium', 'low'].map((priority) => {
                      const priorityItems = regulations.filter(reg => reg.priority === priority);
                      const completedCount = priorityItems.filter(reg => state.checked[reg.id]).length;
                      const percentage = Math.round((completedCount / priorityItems.length) * 100);
                      
                      return (
                        <div key={priority}>
                          <div className="flex justify-between items-center mb-1">
                            <span className={`text-sm ${getPriorityColor(priority)}`}>
                              {priority.charAt(0).toUpperCase() + priority.slice(1)}
                            </span>
                            <span className="text-xs">
                              {completedCount}/{priorityItems.length} ({percentage}%)
                            </span>
                          </div>
                          <div className="w-full bg-muted rounded-full h-1.5">
                            <div 
                              className={`h-1.5 rounded-full transition-all duration-500 ${
                                priority === 'critical' ? 'bg-destructive' : 
                                priority === 'high' ? 'bg-warning' : 
                                priority === 'medium' ? 'bg-secondary' : 
                                'bg-muted-foreground'
                              }`}
                              style={{ width: `${percentage}%` }}
                            ></div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <h4 className="font-bold mb-3">Category Compliance</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {categories.map(category => {
                const progress = calculateCategoryProgress(category);
                return (
                  <Card key={category}>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center mb-2">
                        <h5 className="font-medium">{category}</h5>
                        <span className="text-sm font-medium">{progress}%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full transition-all duration-500 ${
                            progress >= 90 ? 'bg-success' : 
                            progress >= 70 ? 'bg-warning' : 
                            'bg-destructive'
                          }`}
                          style={{ width: `${progress}%` }}
                        ></div>
                      </div>
                      <div className="mt-2 text-xs text-muted-foreground">
                        {regulations.filter(reg => reg.category === category && state.checked[reg.id]).length} of {regulations.filter(reg => reg.category === category).length} requirements met
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>
          
          <TabsContent value="center-info" className="mt-4">
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium block mb-1">Center Name</label>
                <Input
                  value={state.centerInfo.name}
                  onChange={(e) => handleCenterInfoChange('name', e.target.value)}
                  placeholder="Enter child care center name"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium block mb-1">Center Address</label>
                <Input
                  value={state.centerInfo.address}
                  onChange={(e) => handleCenterInfoChange('address', e.target.value)}
                  placeholder="Enter full address"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium block mb-1">License Number</label>
                <Input
                  value={state.centerInfo.license}
                  onChange={(e) => handleCenterInfoChange('license', e.target.value)}
                  placeholder="Enter TN DHS license number"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium block mb-1">Director Name</label>
                <Input
                  value={state.centerInfo.director}
                  onChange={(e) => handleCenterInfoChange('director', e.target.value)}
                  placeholder="Enter director's full name"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium block mb-1">Phone Number</label>
                <Input
                  value={state.centerInfo.phone}
                  onChange={(e) => handleCenterInfoChange('phone', e.target.value)}
                  placeholder="Enter center phone number"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium block mb-1">Email</label>
                <Input
                  value={state.centerInfo.email}
                  onChange={(e) => handleCenterInfoChange('email', e.target.value)}
                  placeholder="Enter center email address"
                />
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="action-plan" className="mt-4">
            {generateCompliancePlan()}
          </TabsContent>
        </Tabs>
        
        <div className="mt-6 flex flex-wrap gap-2">
          <Button onClick={saveData} className="flex items-center gap-2">
            <span>💾</span> Save Progress
          </Button>
          
          <Button onClick={exportData} variant="outline" className="flex items-center gap-2">
            <span>📤</span> Export Data
          </Button>
          
          <div className="relative">
            <Button variant="outline" className="flex items-center gap-2">
              <span>📥</span> Import Data
              <input
                type="file"
                accept=".json"
                onChange={importData}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
            </Button>
          </div>
          
          <Button onClick={handlePrint} variant="secondary" className="flex items-center gap-2">
            <span>🖨️</span> Print Report
          </Button>
          
          <Button onClick={resetData} variant="destructive" className="flex items-center gap-2">
            <span>🗑️</span> Reset All
          </Button>
        </div>
      </div>
      
      {/* Print-specific styles */}
      <style dangerouslySetInnerHTML={{__html: `
        @media print {
          body * {
            visibility: hidden;
          }
          .interactive-element, .interactive-element * {
            visibility: visible;
          }
          .interactive-element {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
          }
          button, select, .tabs-list {
            display: none !important;
          }
        }
      `}} />
    </div>
  );
};

export default RegulationChecklist;
