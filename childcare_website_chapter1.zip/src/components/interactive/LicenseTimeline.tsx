import React, { useState } from 'react';

const LicenseTimeline: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0);
  
  const timelineSteps = [
    {
      title: 'Pre-Licensing Orientation',
      description: 'Attend mandatory orientation with Tennessee Department of Human Services (DHS) to understand licensing requirements under TN Rule 1240-04-01-.03.',
      duration: '1-2 weeks',
      tips: 'Bring questions about Tennessee-specific requirements and take detailed notes on the application process. Visit tn.gov/humanservices for pre-orientation research.'
    },
    {
      title: 'Application Submission',
      description: 'Submit your application to the Tennessee Department of Human Services (DHS), along with the required fees and documentation as specified in TN Rule 1240-04-01-.04.',
      duration: '1 week',
      tips: 'Double-check all forms for completeness and accuracy. Include copies of business organization filings with the Tennessee Secretary of State as required by Tennessee regulations.'
    },
    {
      title: 'Provisional License Period',
      description: 'Tennessee DHS issues a provisional license for 120 days to allow your center to demonstrate compliance with all licensing laws and regulations.',
      duration: '4 months',
      tips: 'Use this period to ensure all staff meet qualification requirements and your facility meets all Tennessee physical facility standards.'
    },
    {
      title: 'Inspections and Compliance Verification',
      description: 'Tennessee DHS conducts at least 4 monitoring visits per year (3 announced, 1 unannounced) to verify compliance with all regulations.',
      duration: '2-4 weeks',
      tips: 'Maintain organized records of staff background checks, child health records, and facility maintenance as required by Tennessee law.'
    },
    {
      title: 'Continuous License Issuance',
      description: 'After successful completion of the provisional period and demonstration of compliance, Tennessee DHS issues a continuous license.',
      duration: '1-2 weeks',
      tips: 'Display your license prominently in your facility as required by Tennessee law. Remember that licenses are not transferable to new addresses or owners.'
    }
  ];
  
  const calculateTotalTime = () => {
    const minWeeks = timelineSteps.reduce((total, step) => {
      const [min] = step.duration.split('-').map(num => parseInt(num));
      return total + min;
    }, 0);
    
    const maxWeeks = timelineSteps.reduce((total, step) => {
      const parts = step.duration.split('-');
      const max = parts.length > 1 ? parseInt(parts[1]) : parseInt(parts[0]);
      return total + max;
    }, 0);
    
    return `${minWeeks}-${maxWeeks} weeks`;
  };
  
  return (
    <div className="interactive-element p-4 border border-input rounded-lg">
      <h3 className="text-xl font-bold mb-4 flex items-center">
        <span className="mr-2">🗓️</span> License Application Timeline
      </h3>
      
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium">Estimated Total Time:</span>
          <span className="text-sm font-bold text-primary">{calculateTotalTime()}</span>
        </div>
        <div className="w-full bg-muted rounded-full h-2.5">
          <div 
            className="bg-primary h-2.5 rounded-full transition-all duration-500" 
            style={{ width: `${((currentStep + 1) / timelineSteps.length) * 100}%` }}
          ></div>
        </div>
      </div>
      
      <div className="relative">
        {timelineSteps.map((step, index) => (
          <div 
            key={index} 
            className={`mb-8 flex ${index % 2 === 0 ? '' : 'flex-row-reverse'}`}
          >
            <div className="flex flex-col items-center">
              <div 
                className={`w-8 h-8 rounded-full flex items-center justify-center z-10 ${
                  index <= currentStep ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
                }`}
                onClick={() => setCurrentStep(index)}
              >
                {index + 1}
              </div>
              {index < timelineSteps.length - 1 && (
                <div 
                  className={`w-1 h-full ${
                    index < currentStep ? 'bg-primary' : 'bg-muted'
                  }`}
                ></div>
              )}
            </div>
            
            <div 
              className={`mx-4 p-4 rounded-lg transition-all duration-300 w-full ${
                index === currentStep ? 'bg-card shadow-md scale-105' : 'bg-background'
              }`}
            >
              <h4 className="font-bold text-lg">{step.title}</h4>
              <p className="text-sm mb-2">{step.description}</p>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Duration: <span className="font-bold text-accent">{step.duration}</span></span>
                <button 
                  className="text-primary hover:underline"
                  onClick={() => alert(`Tip: ${step.tips}`)}
                >
                  💡 Tips
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-6 flex justify-between">
        <button
          onClick={() => setCurrentStep(prev => Math.max(0, prev - 1))}
          disabled={currentStep === 0}
          className="px-4 py-2 bg-accent text-accent-foreground rounded-md hover:bg-accent/80 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          Previous Step
        </button>
        <button
          onClick={() => setCurrentStep(prev => Math.min(timelineSteps.length - 1, prev + 1))}
          disabled={currentStep === timelineSteps.length - 1}
          className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/80 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          Next Step
        </button>
      </div>
    </div>
  );
};

export default LicenseTimeline;
