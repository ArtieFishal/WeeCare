import React, { useState } from 'react';

const AccreditationComparison: React.FC = () => {
  const [selectedAccreditations, setSelectedAccreditations] = useState<string[]>([]);
  const [filterCriteria, setFilterCriteria] = useState({
    cost: 'all',
    duration: 'all',
    difficulty: 'all'
  });
  
  const accreditations = [
    {
      name: 'NAEYC',
      fullName: 'National Association for the Education of Young Children',
      cost: 'high',
      duration: 'long',
      difficulty: 'high',
      tnBenefits: 'Recognized by Tennessee Star Quality Program for highest rating',
      benefits: [
        'Highly recognized and respected in Tennessee',
        'Comprehensive quality standards',
        'Marketing advantage with Tennessee families',
        'Professional development resources aligned with TN Early Learning Standards'
      ],
      requirements: [
        'Extensive documentation',
        'Staff qualifications exceeding Tennessee minimum requirements',
        'Curriculum standards aligned with TN-ELDS',
        'Family engagement',
        'On-site observation'
      ]
    },
    {
      name: 'NECPA',
      fullName: 'National Early Childhood Program Accreditation',
      cost: 'medium',
      duration: 'medium',
      difficulty: 'medium',
      tnBenefits: 'Recognized by Tennessee Star Quality Program',
      benefits: [
        'Recognized by Tennessee Department of Human Services',
        'Focus on health and safety standards that complement Tennessee regulations',
        'Professional development opportunities in Tennessee',
        'Program improvement aligned with Tennessee quality initiatives'
      ],
      requirements: [
        'Self-study',
        'Verification visit',
        'Annual reporting',
        'Staff qualifications meeting Tennessee enhanced standards'
      ]
    },
    {
      name: 'NAC',
      fullName: 'National Accreditation Commission',
      cost: 'medium',
      duration: 'medium',
      difficulty: 'medium',
      tnBenefits: 'Recognized by Tennessee Star Quality Program',
      benefits: [
        'Affordable option for Tennessee providers',
        'Streamlined process',
        'Focus on quality improvement',
        'Technical assistance with Tennessee-specific regulations'
      ],
      requirements: [
        'Self-assessment',
        'On-site validation',
        'Annual reporting',
        'Professional development aligned with Tennessee requirements'
      ]
    },
    {
      name: 'ACSI',
      fullName: 'Association of Christian Schools International',
      cost: 'medium',
      duration: 'medium',
      difficulty: 'medium',
      tnBenefits: 'Popular among Tennessee faith-based programs',
      benefits: [
        'Specifically designed for faith-based programs in Tennessee',
        'Recognized by Tennessee Department of Education',
        'Professional development for Tennessee faith-based educators',
        'Network of Tennessee member schools'
      ],
      requirements: [
        'Biblical integration documentation',
        'Staff qualifications including faith component',
        'Site visit',
        'Compliance with Tennessee regulations for faith-based programs'
      ]
    },
    {
      name: 'APPLE',
      fullName: 'Accredited Professional Preschool Learning Environment',
      cost: 'low',
      duration: 'short',
      difficulty: 'low',
      tnBenefits: 'Good option for smaller Tennessee centers',
      benefits: [
        'Affordable for Tennessee small businesses',
        'Designed for smaller centers common in rural Tennessee',
        'Streamlined process with Tennessee-specific guidance',
        'Practical standards that build on Tennessee basic requirements'
      ],
      requirements: [
        'Portfolio submission',
        'Site visit',
        'Annual updates',
        'Basic standards compliance with Tennessee regulations'
      ]
    }
  ];
  
  const filteredAccreditations = accreditations.filter(acc => {
    return (filterCriteria.cost === 'all' || acc.cost === filterCriteria.cost) &&
           (filterCriteria.duration === 'all' || acc.duration === filterCriteria.duration) &&
           (filterCriteria.difficulty === 'all' || acc.difficulty === filterCriteria.difficulty);
  });
  
  const toggleAccreditation = (name: string) => {
    setSelectedAccreditations(prev => 
      prev.includes(name) 
        ? prev.filter(item => item !== name)
        : [...prev, name]
    );
  };
  
  const getCostLabel = (cost: string) => {
    switch(cost) {
      case 'low': return '$ Low';
      case 'medium': return '$$ Medium';
      case 'high': return '$$$ High';
      default: return cost;
    }
  };
  
  const getDurationLabel = (duration: string) => {
    switch(duration) {
      case 'short': return '⚡ 3-6 months';
      case 'medium': return '⏱️ 6-12 months';
      case 'long': return '🗓️ 12+ months';
      default: return duration;
    }
  };
  
  const getDifficultyLabel = (difficulty: string) => {
    switch(difficulty) {
      case 'low': return '😊 Easy';
      case 'medium': return '😐 Moderate';
      case 'high': return '😓 Challenging';
      default: return difficulty;
    }
  };
  
  return (
    <div className="interactive-element p-4 border border-input rounded-lg">
      <h3 className="text-xl font-bold mb-4 flex items-center">
        <span className="mr-2">🏆</span> Accreditation Comparison Tool
      </h3>
      
      <div className="mb-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Cost</label>
          <select
            value={filterCriteria.cost}
            onChange={(e) => setFilterCriteria({...filterCriteria, cost: e.target.value})}
            className="w-full p-2 rounded-md border border-input bg-background"
          >
            <option value="all">All Costs</option>
            <option value="low">$ Low</option>
            <option value="medium">$$ Medium</option>
            <option value="high">$$$ High</option>
          </select>
        </div>
        
        <div>
          <label className="block text-sm font-medium mb-1">Duration</label>
          <select
            value={filterCriteria.duration}
            onChange={(e) => setFilterCriteria({...filterCriteria, duration: e.target.value})}
            className="w-full p-2 rounded-md border border-input bg-background"
          >
            <option value="all">All Durations</option>
            <option value="short">Short (3-6 months)</option>
            <option value="medium">Medium (6-12 months)</option>
            <option value="long">Long (12+ months)</option>
          </select>
        </div>
        
        <div>
          <label className="block text-sm font-medium mb-1">Difficulty</label>
          <select
            value={filterCriteria.difficulty}
            onChange={(e) => setFilterCriteria({...filterCriteria, difficulty: e.target.value})}
            className="w-full p-2 rounded-md border border-input bg-background"
          >
            <option value="all">All Difficulty Levels</option>
            <option value="low">Easy</option>
            <option value="medium">Moderate</option>
            <option value="high">Challenging</option>
          </select>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {filteredAccreditations.map(acc => (
          <div 
            key={acc.name}
            className={`p-4 rounded-lg border transition-all cursor-pointer ${
              selectedAccreditations.includes(acc.name) 
                ? 'border-primary bg-primary/10' 
                : 'border-input bg-card'
            }`}
            onClick={() => toggleAccreditation(acc.name)}
          >
            <div className="flex justify-between items-start mb-2">
              <h4 className="font-bold">{acc.name}</h4>
              <input 
                type="checkbox" 
                checked={selectedAccreditations.includes(acc.name)}
                onChange={() => toggleAccreditation(acc.name)}
                className="h-4 w-4"
              />
            </div>
            <p className="text-xs text-muted-foreground mb-3">{acc.fullName}</p>
            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span>Cost:</span>
                <span className="font-medium">{getCostLabel(acc.cost)}</span>
              </div>
              <div className="flex justify-between">
                <span>Duration:</span>
                <span className="font-medium">{getDurationLabel(acc.duration)}</span>
              </div>
              <div className="flex justify-between">
                <span>Difficulty:</span>
                <span className="font-medium">{getDifficultyLabel(acc.difficulty)}</span>
              </div>
              <div className="mt-2 pt-2 border-t border-border">
                <span className="text-xs font-medium text-primary">Tennessee Benefit:</span>
                <p className="text-xs mt-1">{acc.tnBenefits}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {selectedAccreditations.length > 0 && (
        <div className="mt-6 p-4 bg-card rounded-lg">
          <h4 className="font-bold mb-3">Comparison of Selected Accreditations</h4>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2">Accreditation</th>
                  <th className="text-left py-2">Benefits</th>
                  <th className="text-left py-2">Requirements</th>
                </tr>
              </thead>
              <tbody>
                {accreditations
                  .filter(acc => selectedAccreditations.includes(acc.name))
                  .map(acc => (
                    <tr key={acc.name} className="border-b">
                      <td className="py-2 pr-4 align-top">
                        <div className="font-bold">{acc.name}</div>
                        <div className="text-xs text-muted-foreground">{acc.fullName}</div>
                      </td>
                      <td className="py-2 pr-4 align-top">
                        <ul className="list-disc list-inside">
                          {acc.benefits.map((benefit, i) => (
                            <li key={i} className="text-xs">{benefit}</li>
                          ))}
                        </ul>
                      </td>
                      <td className="py-2 align-top">
                        <ul className="list-disc list-inside">
                          {acc.requirements.map((req, i) => (
                            <li key={i} className="text-xs">{req}</li>
                          ))}
                        </ul>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default AccreditationComparison;
