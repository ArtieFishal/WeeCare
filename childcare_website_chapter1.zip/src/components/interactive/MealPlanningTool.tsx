import React, { useState } from 'react';

const MealPlanningTool: React.FC = () => {
  const [mealPlan, setMealPlan] = useState({
    monday: { breakfast: '', am_snack: '', lunch: '', pm_snack: '', notes: '' },
    tuesday: { breakfast: '', am_snack: '', lunch: '', pm_snack: '', notes: '' },
    wednesday: { breakfast: '', am_snack: '', lunch: '', pm_snack: '', notes: '' },
    thursday: { breakfast: '', am_snack: '', lunch: '', pm_snack: '', notes: '' },
    friday: { breakfast: '', am_snack: '', lunch: '', pm_snack: '', notes: '' }
  });
  
  const [currentDay, setCurrentDay] = useState('monday');
  const [currentMeal, setCurrentMeal] = useState('breakfast');
  const [showNutritionInfo, setShowNutritionInfo] = useState(false);
  const [selectedAgeGroup, setSelectedAgeGroup] = useState('preschool');
  const [selectedDietaryRestrictions, setSelectedDietaryRestrictions] = useState<string[]>([]);
  
  const days = [
    { id: 'monday', label: 'Monday' },
    { id: 'tuesday', label: 'Tuesday' },
    { id: 'wednesday', label: 'Wednesday' },
    { id: 'thursday', label: 'Thursday' },
    { id: 'friday', label: 'Friday' }
  ];
  
  const meals = [
    { id: 'breakfast', label: 'Breakfast', icon: '🍳' },
    { id: 'am_snack', label: 'AM Snack', icon: '🍎' },
    { id: 'lunch', label: 'Lunch', icon: '🥪' },
    { id: 'pm_snack', label: 'PM Snack', icon: '🥕' }
  ];
  
  const ageGroups = [
    { id: 'infant', label: 'Infants (0-12 months)' },
    { id: 'toddler', label: 'Toddlers (1-3 years)' },
    { id: 'preschool', label: 'Preschool (3-5 years)' },
    { id: 'schoolage', label: 'School Age (5+ years)' }
  ];
  
  const dietaryRestrictions = [
    { id: 'dairy', label: 'Dairy-Free' },
    { id: 'gluten', label: 'Gluten-Free' },
    { id: 'nut', label: 'Nut-Free' },
    { id: 'egg', label: 'Egg-Free' },
    { id: 'vegetarian', label: 'Vegetarian' },
    { id: 'vegan', label: 'Vegan' }
  ];
  
  const mealSuggestions = {
    breakfast: [
      'Whole grain cereal with milk and banana slices',
      'Scrambled eggs with whole wheat toast and orange slices',
      'Yogurt parfait with granola and berries',
      'Oatmeal with apple chunks and cinnamon',
      'Whole grain pancakes with fruit topping'
    ],
    am_snack: [
      'Apple slices with cheese cubes',
      'Carrot sticks with hummus',
      'Yogurt with berries',
      'Whole grain crackers with cream cheese',
      'Banana and milk'
    ],
    lunch: [
      'Turkey and cheese sandwich on whole wheat bread with cucumber slices',
      'Chicken and vegetable soup with whole grain roll',
      'Bean and cheese quesadilla with bell pepper strips',
      'Tuna salad on whole wheat with cherry tomatoes',
      'Pasta with tomato sauce and vegetables'
    ],
    pm_snack: [
      'Celery with sunflower seed butter',
      'Fruit smoothie with yogurt',
      'Whole grain muffin with milk',
      'Trail mix with dried fruit',
      'Cucumber rounds with guacamole'
    ]
  };
  
  const nutritionGuidelines = {
    infant: {
      title: 'Infant Nutrition (0-12 months)',
      guidelines: [
        'Breast milk or formula is the primary source of nutrition for the first year',
        'Introduce solid foods around 6 months, starting with iron-fortified cereals',
        'Gradually introduce pureed fruits, vegetables, and proteins',
        'Avoid honey until after 12 months due to botulism risk',
        'No cow\'s milk until 12 months of age'
      ]
    },
    toddler: {
      title: 'Toddler Nutrition (1-3 years)',
      guidelines: [
        'Offer a variety of foods from all food groups',
        'Serve whole milk until age 2, then can transition to lower-fat options',
        'Limit juice to 4 oz per day of 100% fruit juice',
        'Offer 2-3 snacks per day in addition to meals',
        'Serve finger foods that are easy to handle and not choking hazards'
      ]
    },
    preschool: {
      title: 'Preschool Nutrition (3-5 years)',
      guidelines: [
        'Serve 1/4 to 1/3 adult portion sizes',
        'Include at least one fruit and vegetable at each meal',
        'Offer whole grains for at least half of grain servings',
        'Provide protein at each meal',
        'Limit added sugars and highly processed foods'
      ]
    },
    schoolage: {
      title: 'School Age Nutrition (5+ years)',
      guidelines: [
        'Increase portion sizes as children grow',
        'Encourage water as the primary beverage',
        'Include a variety of colorful fruits and vegetables daily',
        'Teach about balanced nutrition and food groups',
        'Involve children in meal planning and preparation'
      ]
    }
  };
  
  const handleMealChange = (value: string) => {
    setMealPlan({
      ...mealPlan,
      [currentDay]: {
        ...mealPlan[currentDay],
        [currentMeal]: value
      }
    });
  };
  
  const handleNotesChange = (day: string, value: string) => {
    setMealPlan({
      ...mealPlan,
      [day]: {
        ...mealPlan[day],
        notes: value
      }
    });
  };
  
  const handleSuggestionClick = (suggestion: string) => {
    handleMealChange(suggestion);
  };
  
  const handleToggleDietaryRestriction = (restriction: string) => {
    if (selectedDietaryRestrictions.includes(restriction)) {
      setSelectedDietaryRestrictions(selectedDietaryRestrictions.filter(r => r !== restriction));
    } else {
      setSelectedDietaryRestrictions([...selectedDietaryRestrictions, restriction]);
    }
  };
  
  const handleClearDay = (day: string) => {
    if (confirm(`Clear all meals for ${day}?`)) {
      setMealPlan({
        ...mealPlan,
        [day]: { breakfast: '', am_snack: '', lunch: '', pm_snack: '', notes: '' }
      });
    }
  };
  
  const handleClearWeek = () => {
    if (confirm('Clear the entire week\'s meal plan?')) {
      setMealPlan({
        monday: { breakfast: '', am_snack: '', lunch: '', pm_snack: '', notes: '' },
        tuesday: { breakfast: '', am_snack: '', lunch: '', pm_snack: '', notes: '' },
        wednesday: { breakfast: '', am_snack: '', lunch: '', pm_snack: '', notes: '' },
        thursday: { breakfast: '', am_snack: '', lunch: '', pm_snack: '', notes: '' },
        friday: { breakfast: '', am_snack: '', lunch: '', pm_snack: '', notes: '' }
      });
    }
  };
  
  const handleCopyDay = (fromDay: string, toDay: string) => {
    setMealPlan({
      ...mealPlan,
      [toDay]: { ...mealPlan[fromDay] }
    });
  };
  
  const getDayCompletionStatus = (day: string) => {
    const dayMeals = mealPlan[day];
    const totalMeals = Object.keys(dayMeals).filter(key => key !== 'notes').length;
    const completedMeals = Object.keys(dayMeals)
      .filter(key => key !== 'notes' && dayMeals[key] !== '')
      .length;
    
    return {
      completed: completedMeals,
      total: totalMeals,
      percentage: Math.round((completedMeals / totalMeals) * 100)
    };
  };
  
  const getMealIcon = (mealId: string) => {
    return meals.find(meal => meal.id === mealId)?.icon || '';
  };
  
  return (
    <div className="interactive-element p-4 border border-input rounded-lg">
      <h3 className="text-xl font-bold mb-4 flex items-center">
        <span className="mr-2">🍽️</span> Meal Planning Tool
      </h3>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium mb-1">Age Group</label>
          <select
            value={selectedAgeGroup}
            onChange={(e) => setSelectedAgeGroup(e.target.value)}
            className="w-full p-2 border border-input rounded-md bg-background"
          >
            {ageGroups.map(group => (
              <option key={group.id} value={group.id}>{group.label}</option>
            ))}
          </select>
        </div>
        
        <div className="md:col-span-2">
          <label className="block text-sm font-medium mb-1">Dietary Restrictions</label>
          <div className="flex flex-wrap gap-2">
            {dietaryRestrictions.map(restriction => (
              <button
                key={restriction.id}
                onClick={() => handleToggleDietaryRestriction(restriction.id)}
                className={`px-3 py-1 rounded-full text-sm transition-colors ${
                  selectedDietaryRestrictions.includes(restriction.id)
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted hover:bg-muted/80'
                }`}
              >
                {restriction.label}
              </button>
            ))}
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4 mb-6">
        <div className="md:col-span-1">
          <div className="bg-card rounded-lg overflow-hidden h-full">
            <div className="p-3 bg-muted font-medium">Days</div>
            <div className="divide-y">
              {days.map(day => {
                const status = getDayCompletionStatus(day.id);
                return (
                  <button
                    key={day.id}
                    onClick={() => setCurrentDay(day.id)}
                    className={`w-full p-3 text-left transition-colors ${
                      currentDay === day.id
                        ? 'bg-primary/10'
                        : 'hover:bg-muted/50'
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <span className={currentDay === day.id ? 'font-medium' : ''}>
                        {day.label}
                      </span>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        status.percentage === 100
                          ? 'bg-green-200 text-green-800 dark:bg-green-900 dark:text-green-100'
                          : status.percentage > 0
                            ? 'bg-amber-200 text-amber-800 dark:bg-amber-900 dark:text-amber-100'
                            : 'bg-muted text-muted-foreground'
                      }`}>
                        {status.completed}/{status.total}
                      </span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-1 mt-1">
                      <div 
                        className="h-1 rounded-full transition-all duration-500"
                        style={{ 
                          width: `${status.percentage}%`,
                          backgroundColor: status.percentage === 100 
                            ? 'var(--success, var(--secondary))' 
                            : 'var(--primary)'
                        }}
                      ></div>
                    </div>
                  </button>
                );
              })}
            </div>
            <div className="p-3 border-t">
              <button
                onClick={handleClearWeek}
                className="w-full px-3 py-1 bg-muted text-muted-foreground rounded-md text-sm hover:bg-muted/80 transition-colors"
              >
                Clear Week
              </button>
            </div>
          </div>
        </div>
        
        <div className="md:col-span-5">
          <div className="bg-card rounded-lg overflow-hidden">
            <div className="p-3 bg-muted flex justify-between items-center">
              <h4 className="font-medium">{days.find(d => d.id === currentDay)?.label} Menu</h4>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleClearDay(currentDay)}
                  className="px-3 py-1 bg-muted text-muted-foreground rounded-md text-sm hover:bg-muted/80 transition-colors"
                >
                  Clear Day
                </button>
                <div className="relative">
                  <select
                    onChange={(e) => {
                      if (e.target.value) {
                        handleCopyDay(e.target.value, currentDay);
                        e.target.value = '';
                      }
                    }}
                    className="p-1 text-sm border border-input rounded-md bg-background"
                    defaultValue=""
                  >
                    <option value="" disabled>Copy from...</option>
                    {days.filter(d => d.id !== currentDay).map(day => (
                      <option key={day.id} value={day.id}>{day.label}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
            
            <div className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                {meals.map(meal => (
                  <button
                    key={meal.id}
                    onClick={() => setCurrentMeal(meal.id)}
                    className={`p-3 rounded-lg transition-colors ${
                      currentMeal === meal.id
                        ? 'bg-primary text-primary-foreground'
                        : mealPlan[currentDay][meal.id]
                          ? 'bg-secondary/50 hover:bg-secondary/80'
                          : 'bg-muted hover:bg-muted/80'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <span className="mr-2 text-xl">{meal.icon}</span>
                        <span className="font-medium">{meal.label}</span>
                      </div>
                      {mealPlan[currentDay][meal.id] && (
                        <span className="text-xs bg-primary/20 dark:bg-primary/40 px-2 py-0.5 rounded-full">
                          ✓
                        </span>
                      )}
                    </div>
                  </button>
                ))}
              </div>
              
              <div className="mb-4">
                <div className="flex items-center mb-2">
                  <h5 className="font-medium flex items-center">
                    <span className="mr-2">{getMealIcon(currentMeal)}</span>
                    {meals.find(m => m.id === currentMeal)?.label}
                  </h5>
                </div>
                <textarea
                  value={mealPlan[currentDay][currentMeal]}
                  onChange={(e) => handleMealChange(e.target.value)}
                  className="w-full p-2 border border-input rounded-md bg-background"
                  placeholder={`Enter ${meals.find(m => m.id === currentMeal)?.label.toLowerCase()} menu items...`}
                  rows={3}
                ></textarea>
              </div>
              
              <div className="mb-4">
                <h5 className="font-medium mb-2">Suggestions</h5>
                <div className="flex flex-wrap gap-2">
                  {mealSuggestions[currentMeal].map((suggestion, index) => (
                    <button
                      key={index}
                      onClick={() => handleSuggestionClick(suggestion)}
                      className="px-3 py-1 bg-accent text-accent-foreground rounded-md text-sm hover:bg-accent/80 transition-colors"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>
              
              <div>
                <label className="block font-medium mb-2">Notes for {days.find(d => d.id === currentDay)?.label}</label>
                <textarea
                  value={mealPlan[currentDay].notes}
                  onChange={(e) => handleNotesChange(currentDay, e.target.value)}
                  className="w-full p-2 border border-input rounded-md bg-background"
                  placeholder="Add any special notes, substitutions, or reminders..."
                  rows={2}
                ></textarea>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mb-6">
        <button
          onClick={() => setShowNutritionInfo(!showNutritionInfo)}
          className="flex items-center text-sm font-medium"
        >
          <span className="mr-2">{showNutritionInfo ? '▼' : '►'}</span>
          Nutrition Guidelines for {ageGroups.find(g => g.id === selectedAgeGroup)?.label}
        </button>
        
        {showNutritionInfo && (
          <div className="mt-2 p-4 bg-card rounded-lg">
            <h5 className="font-medium mb-2">{nutritionGuidelines[selectedAgeGroup].title}</h5>
            <ul className="list-disc pl-5 space-y-1">
              {nutritionGuidelines[selectedAgeGroup].guidelines.map((guideline, index) => (
                <li key={index} className="text-sm">{guideline}</li>
              ))}
            </ul>
          </div>
        )}
      </div>
      
      <div className="flex justify-between">
        <button
          onClick={() => alert('Shopping list generated!')}
          className="px-4 py-2 bg-accent text-accent-foreground rounded-md hover:bg-accent/80 transition-colors"
        >
          Generate Shopping List
        </button>
        <button
          onClick={() => alert('Meal plan saved and ready to print!')}
          className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/80 transition-colors"
        >
          Save & Print Plan
        </button>
      </div>
    </div>
  );
};

export default MealPlanningTool;
