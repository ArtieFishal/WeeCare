import React from 'react';

interface LocationData {
  name: string;
  address: string;
  county: string;
  proximity: {
    residential: number;
    schools: number;
    parks: number;
    publicTransport: number;
  };
  demographics: {
    childrenPopulation: number;
    averageIncome: number;
    growthRate: number;
  };
  facility: {
    size: number;
    parking: number;
    outdoor: number;
    accessibility: number;
  };
  tennessee: {
    zoningCompliance: number;
    childcareDeserts: number;
    subsidyEligibility: number;
    disasterRisk: number;
  };
}

const LocationCalculator: React.FC = () => {
  const [location, setLocation] = React.useState<LocationData>({
    name: '',
    address: '',
    county: '',
    proximity: {
      residential: 5,
      schools: 5,
      parks: 5,
      publicTransport: 5
    },
    demographics: {
      childrenPopulation: 5,
      averageIncome: 5,
      growthRate: 5
    },
    facility: {
      size: 5,
      parking: 5,
      outdoor: 5,
      accessibility: 5
    },
    tennessee: {
      zoningCompliance: 5,
      childcareDeserts: 5,
      subsidyEligibility: 5,
      disasterRisk: 5
    }
  });
  
  const [suitabilityScore, setSuitabilityScore] = React.useState(0);
  
  React.useEffect(() => {
    // Calculate suitability score based on all factors including Tennessee-specific factors
    const proximityScore = Object.values(location.proximity).reduce((sum, val) => sum + val, 0) / 4;
    const demographicsScore = Object.values(location.demographics).reduce((sum, val) => sum + val, 0) / 3;
    const facilityScore = Object.values(location.facility).reduce((sum, val) => sum + val, 0) / 4;
    const tennesseeScore = Object.values(location.tennessee).reduce((sum, val) => sum + val, 0) / 4;
    
    // Tennessee-specific factors are weighted more heavily (40%) in the final score
    const totalScore = (proximityScore * 0.2) + (demographicsScore * 0.2) + (facilityScore * 0.2) + (tennesseeScore * 0.4);
    setSuitabilityScore(Math.round(totalScore * 10) / 10);
  }, [location]);
  
  const handleSliderChange = (category: keyof Omit<LocationData, 'name' | 'address' | 'county'>, factor: string, value: number) => {
    setLocation(prev => ({
      ...prev,
      [category]: {
        ...(prev[category] as Record<string, number>),
        [factor]: value
      }
    }));
  };
  
  const renderSliders = (category: keyof Omit<LocationData, 'name' | 'address' | 'county'>, factors: Record<string, number>) => {
    return Object.entries(factors).map(([factor, value]) => (
      <div key={`${category}-${factor}`} className="mb-4">
        <div className="flex justify-between items-center mb-1">
          <label className="text-sm font-medium capitalize">
            {factor.replace(/([A-Z])/g, ' $1').trim()}
          </label>
          <span className="text-sm font-bold">{value.toString()}/10</span>
        </div>
        <input
          type="range"
          min="1"
          max="10"
          value={value.toString()}
          onChange={(e) => handleSliderChange(category, factor, parseInt(e.target.value))}
          className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer"
        />
      </div>
    ));
  };
  
  return (
    <div className="interactive-element p-4 border border-input rounded-lg">
      <h3 className="text-xl font-bold mb-4 flex items-center">
        <span className="mr-2">📍</span> Location Suitability Calculator
      </h3>
      
      <div className="mb-6">
        <div className="flex flex-col mb-4">
          <label className="text-sm font-medium mb-1">Location Name</label>
          <input
            type="text"
            value={location.name}
            onChange={(e) => setLocation(prev => ({ ...prev, name: e.target.value }))}
            placeholder="Enter location name"
            className="p-2 border border-input rounded-md bg-background"
          />
        </div>
        
        <div className="flex flex-col mb-4">
          <label className="text-sm font-medium mb-1">Address</label>
          <input
            type="text"
            value={location.address}
            onChange={(e) => setLocation(prev => ({ ...prev, address: e.target.value }))}
            placeholder="Enter address"
            className="p-2 border border-input rounded-md bg-background"
          />
        </div>
        
        <div className="flex flex-col mb-4">
          <label className="text-sm font-medium mb-1">Tennessee County</label>
          <select
            value={location.county}
            onChange={(e) => setLocation(prev => ({ ...prev, county: e.target.value }))}
            className="p-2 border border-input rounded-md bg-background"
          >
            <option value="">Select a county</option>
            <option value="Davidson">Davidson</option>
            <option value="Shelby">Shelby</option>
            <option value="Knox">Knox</option>
            <option value="Hamilton">Hamilton</option>
            <option value="Rutherford">Rutherford</option>
            <option value="Williamson">Williamson</option>
            <option value="Montgomery">Montgomery</option>
            <option value="Sumner">Sumner</option>
            <option value="Wilson">Wilson</option>
            <option value="Blount">Blount</option>
          </select>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <div className="bg-card p-4 rounded-lg">
          <h4 className="font-bold text-secondary mb-3">Proximity Factors</h4>
          {renderSliders('proximity', location.proximity)}
        </div>
        
        <div className="bg-card p-4 rounded-lg">
          <h4 className="font-bold text-secondary mb-3">Demographic Factors</h4>
          {renderSliders('demographics', location.demographics)}
        </div>
        
        <div className="bg-card p-4 rounded-lg">
          <h4 className="font-bold text-secondary mb-3">Facility Factors</h4>
          {renderSliders('facility', location.facility)}
        </div>
        
        <div className="bg-card p-4 rounded-lg border-2 border-primary">
          <h4 className="font-bold text-primary mb-3">Tennessee Factors</h4>
          {renderSliders('tennessee', location.tennessee)}
        </div>
      </div>
      
      <div className="bg-card p-4 rounded-lg mb-6">
        <h4 className="font-bold mb-3">Suitability Score</h4>
        <div className="flex items-center">
          <div className="w-full bg-muted rounded-full h-4 mr-4">
            <div 
              className="h-4 rounded-full transition-all duration-500"
              style={{ 
                width: `${suitabilityScore * 10}%`,
                backgroundColor: suitabilityScore < 3 ? 'var(--destructive)' : 
                                suitabilityScore < 7 ? 'var(--warning, var(--highlight))' : 
                                'var(--success, var(--secondary))'
              }}
            ></div>
          </div>
          <span className="text-2xl font-bold">{suitabilityScore}/10</span>
        </div>
        
        <div className="mt-4 text-sm">
          {suitabilityScore < 3 && (
            <p className="text-destructive">This location is not suitable for a Tennessee child care center.</p>
          )}
          {suitabilityScore >= 3 && suitabilityScore < 7 && (
            <p className="text-warning">This location has potential but consider addressing the lower-scoring Tennessee factors.</p>
          )}
          {suitabilityScore >= 7 && (
            <p className="text-success">This location is highly suitable for a Tennessee child care center!</p>
          )}
          <p className="mt-2 text-xs">
            <strong>Note:</strong> Tennessee-specific factors are weighted at 40% of the total score, as they are critical for regulatory compliance and funding eligibility in Tennessee.
          </p>
        </div>
      </div>
      
      <div className="flex justify-end">
        <button 
          className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/80 transition-colors"
          onClick={() => alert(`Location analysis saved for ${location.name || 'Unnamed Location'}`)}
        >
          Save Analysis
        </button>
      </div>
    </div>
  );
};

export default LocationCalculator;
