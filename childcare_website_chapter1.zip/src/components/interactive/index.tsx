import React from 'react';
import * as PlaceholderComponents from './PlaceholderComponents';

// Map chapter IDs to their respective interactive components
const interactiveComponents = {
  1: PlaceholderComponents.RegulationChecklist,
  2: PlaceholderComponents.LicenseTimeline,
  3: PlaceholderComponents.AccreditationComparison,
  4: PlaceholderComponents.LocationCalculator,
  5: PlaceholderComponents.RoomLayoutDesigner,
  6: PlaceholderComponents.EquipmentBudgetPlanner,
  7: PlaceholderComponents.JobDescriptionGenerator,
  8: PlaceholderComponents.StaffQualificationTracker,
  9: PlaceholderComponents.CurriculumPlanner,
  10: PlaceholderComponents.DailyScheduleBuilder,
  11: PlaceholderComponents.ActivityGenerator,
  12: PlaceholderComponents.ChildAssessmentTool,
  13: PlaceholderComponents.HealthSafetyChecklist,
  14: PlaceholderComponents.MealPlanningTool,
  15: PlaceholderComponents.ParentCommunicationPortal,
  16: PlaceholderComponents.BudgetCalculator,
  17: PlaceholderComponents.MarketingStrategiesPlanner
};

export { interactiveComponents };
